<?php
class Person {
    function __get( $property ) {
        $method = "get{$property}";
        if ( method_exists( $this, $method ) ) {
            return $this->$method();
        }
    }
                                                                                
    function getName() {
        return "Bob";
    }
                                                                                
    function getAge() {
        return 44;
    }
}

$p = new Person();
print $p->name;
// output: 
// Bob
?>
