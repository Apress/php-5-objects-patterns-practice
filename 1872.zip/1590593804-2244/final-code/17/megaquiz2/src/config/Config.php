<?php

/*
 * Quick and dirty Conf class
 *
 */
class Config {
    public $dbname ="@dbname@";
    public $dbpass ="@dbpass@";
    public $dbhost ="@dbhost@";
}
