<?php
/*
 set up script for transaction script example
*/

require_once( "DB.php");

$db = DB::Connect( "sqlite://./woo/data/woo.db" );
@$db->query( "DROP TABLE venue" );
$db->query( "CREATE TABLE venue ( id INT PRIMARY KEY, name TEXT )" );

$db->query( "DROP TABLE space" );
$db->query( "CREATE TABLE space ( id INT PRIMARY KEY, venue INT, name TEXT )" );

@$db->query( "DROP TABLE event" );
$db->query( "CREATE TABLE event ( id INT PRIMARY KEY, space INT, start long, duration int, name text )" );
?>
