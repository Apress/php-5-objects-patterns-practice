<?php
class Person {
    private $_name;
    private $_age;

    function __set( $property, $value ) {
        $method = "set{$property}";
        if ( method_exists( $this, $method ) ) {
            return $this->$method( $value );
        }
    }

    function setName( $name ) {
        $this->_name = strtoupper($name);
    }

    function setAge( $age ) {
        $this->_age = $age;
    }
}

$p = new Person();
$p->name = "bob";
$p->age  = 44;
print_r( $p );
?>
