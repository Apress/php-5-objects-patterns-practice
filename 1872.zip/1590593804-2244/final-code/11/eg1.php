<?php
require( "lib/Context.php");
require( "lib/ML_Interpreter.php");

$context = new Context();
$literal = new LiteralExpression( 'four');
$literal->interpret( $context );
print $context->lookup( $literal );
?>
