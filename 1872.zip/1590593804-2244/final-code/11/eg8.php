<?php

class Login {
    const LOGIN_USER_UNKNOWN = 1;
    const LOGIN_WRONG_PASS   = 2;
    const LOGIN_ACCESS       = 3;

    function handleLogin( $user, $pass, $ip ) {
        switch ( rand(1,3) ) {
            case 1: 
                $this->setStatus( self::LOGIN_ACCESS );
                return true;
            case 2:
                $this->setStatus( self::LOGIN_WRONG_PASS );
                return false;        
            case 3:
                $this->setStatus( self::LOGIN_USER_UNKNOWN );
                return false;        
        }
    }

    private function setStatus( $status ) {
        $this->status = $status; 
    }

    function loginStatus() {
        return $this->status;
    }

}

$login = new Login();
$login->handleLogin( "bob","mypass", '158.152.55.35' );
print $login->loginStatus();
?>
