<?php
class Validator {
    private $store;
    public function __construct( UserStore $store ) {
        $this->store = $store;
    }

    public function getStore() {
        return $this->store;
    }

    public function validateUser( $mail, $pass ) {
        if ( ! is_array($user = $this->store->getUser( $mail )) ) {
            return false;
        }
        if ( $user['pass'] == $pass ) {
            return true;
        }
        return false;
    }
}
?>
