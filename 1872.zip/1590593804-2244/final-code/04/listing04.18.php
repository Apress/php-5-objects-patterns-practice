<?php

class StringThing {}
$st = new StringThing();
print $st;
?>
