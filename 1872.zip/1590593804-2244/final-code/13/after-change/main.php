<?php

require_once( "User.php" );
require_once( "UserStore.php" );
require_once( "Validator.php" );

$user = new User( 'bob', 'williams', 'bob@example.com', 'bibblepops' );
print $user->fullname();

$store = new UserStore();
$store->addUser( 'bob williams', 'bob@example.com', 'bibblepops');
$validator = new Validator( $store );

if ( $validator->validateUser('bob@example.com', 'bibblepops') ) {
    print "pass friend\n";
} else {
    print "who are you?\n";
}

?>
