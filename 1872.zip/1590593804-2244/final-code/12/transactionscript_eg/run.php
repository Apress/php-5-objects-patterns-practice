<?php
require_once('DB.php');
require_once('woo/process/VenueManager.php');
require_once('woo/base/Registry.php');

$halfhour = (60*30);
$hour     = (60*60);
$day      = (24*$hour);

$db = DB::Connect( "sqlite://./woo/data/woo.db" );
woo_base_RequestRegistry::setDB( $db ); 


$mgr = new woo_process_VenueManager();
$ret = $mgr->addVenue( "The Eyeball Inn", 
                array( 'The Room Upstairs', 'Main Bar' ));
$space_id = $ret['spaces'][0][0];
$mgr->bookEvent( $space_id, "Running like the rain", time()+($day), ($hour) ); 
$mgr->bookEvent( $space_id, "Running like the trees", time()+($day-$hour), (60*60) ); 

?>
