<?php
require_once( "listing03.05.php" );

class ShopProductWriter {
    public function write( $shopProduct ) {
        $str  = "{$shopProduct->title}: ";   
        $str .= $shopProduct->getProducer();
        $str .= " ({$shopProduct->price})\n";
        print $str;
    }
}
$product1 = new ShopProduct( "My Antonia", "Willa", "Cather", 5.99 );
$writer = new ShopProductWriter();
$writer->write( $product1 );

?>
