<?php
class ShopProduct {
    // class body
}
$product1 = new ShopProduct();
$product2 = new ShopProduct();

$product1->title="My Antonia";
$product2->title="Catch 22";

print  $product1->title."\n"; // My Antonia
print "{$product1->title}\n"; // Catch 22
?>
