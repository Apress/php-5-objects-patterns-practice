<?php
/**
 * @package  quizobjects
 */

/**
 * @license   http://www.example.com Borsetshire Open License
 * @package  quizobjects
 */

>>>>>>> 1.2
class User {}
?>

