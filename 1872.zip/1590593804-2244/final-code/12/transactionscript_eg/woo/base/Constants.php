<?php

class woo_base_Constants {
    public static $DATA_DIR = "%DATA_DIR%";
    public static $DSN = '%DSN';
}
?>
