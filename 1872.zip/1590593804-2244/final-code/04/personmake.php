<?php

require_once("DB.php");
$dsn = "mysql://$user:$pass@$host/$database";

$dsn = "sqlite://./persons.db";    

$db = DB::connect($dsn);
if ( DB::isError($db) ) {    
    die ( $db->getMessage() );
}

@$db->query( "DROP TABLE persons" );
$create =   "CREATE TABLE persons (  
                                    id INT PRIMARY KEY, 
                                    name varchar(255), 
                                    age int
                                    )";
$create_result = $db->query( $create );
if ( DB::isError( $create_result ) ) {    
    die ($create_result->getMessage());
}
die;
$products = array(  
                array(  "id"=>1, 
                        "type"=>"book", 
                        "firstname"=>"willa",
                        "mainname"=>"cather",
                        "title"=>"My Antonia",
                        "price"=>10.99,
                        "numpages"=>300
                ),
                array(  "id"=>2,
                        "type"=>"cd", 
                        "firstname"=>"The",
                        "mainname"=>"Alabama 3",
                        "title"=>"Exile on Coldharbour Lane",
                        "price"=>10.99,
                        "playlength"=>180
                )
            );

foreach ( $products as $row ) {                    
    $id = $db->nextId('products_sequence');
    $row['id'] = $id;
    print "Inserting {$row['firstname']} {$row['mainname']}: $id<br />\n";
    $db->autoExecute( 'products', $row, DB_AUTOQUERY_INSERT );
}

$query = "SELECT * FROM products";
$query_result = $db->query( $query );

if ( DB::isError( $query_result ) ) {    
    die ($query_result->getMessage());
}

while ( $row = $query_result->fetchRow( DB_FETCHMODE_ASSOC ) ) {
    print_r( $row );
}

$query_result->free();
$db->disconnect();

?>
