<?php
require_once( "listing03.10.php" );

class ShopProductWriter {
    public function write( $shopProduct ) {
        if ( ! ( $shopProduct instanceof CdWriter )  &&
             ! ( $shopProduct instanceof BookProduct ) ) {
            die( "wrong type supplied" );
        }

        $str  = "{$shopProduct->title}: ";   
        $str .= $shopProduct->getProducer();
        $str .= " ({$shopProduct->price})\n";
        print $str;
    }
}
// class Wrong { }
$product1 = new CdProduct( "My Antonia", "Willa", "Cather", 5.99, 300 );
$writer = new ShopProductWriter();
$writer->write( $product1 );
// $wrong  = new Wrong();
// $writer->write( $wrong );

?>
