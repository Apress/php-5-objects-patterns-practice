<?php
require_once( "../03/listing03.05.php" );

abstract class ShopProductWriter {
    abstract static function write( ShopProduct $shopProduct );
}

class TextProductWriter extends ShopProductWriter {
    static function write( ShopProduct $shopProduct ) {
        $str  = "{$shopProduct->title}: ";   
        $str .= $shopProduct->getProducer();
        $str .= " ({$shopProduct->price})\n";
        print $str;
    }
}

$product1 = new ShopProduct( "My Antonia", "Willa", "Cather", 5.99 );
//$writer = new ShopProductWriter();
TextProductWriter::write( $product1 );

?>
