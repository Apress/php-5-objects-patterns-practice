<?php

$form_input = "print file_get_contents('/etc/passwd');";
eval( $form_input );

?>
