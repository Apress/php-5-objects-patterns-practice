<?php
require( "lib/Context.php");
require( "lib/ML_Interpreter.php");


$context = new Context();
$myvar = new VariableExpression( 'input', 'four');
$myvar->interpret( $context );
print $context->lookup( $myvar );
// output: four

$newvar = new VariableExpression( 'input' );
$newvar->interpret( $context );
print $context->lookup( $newvar );
// output: four

$myvar->setValue("five");
$myvar->interpret( $context );
print $context->lookup( $myvar );
// output: five
print $context->lookup( $newvar );
// output: five

?>
