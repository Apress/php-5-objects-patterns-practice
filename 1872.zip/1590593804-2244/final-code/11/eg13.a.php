<?php
class User{
    private $name;
    function __construct( $name ) {
        $this->name = $name;
    }
}

class MessageSystem {
    function send( $mail, $msg, $topic ) {
        return true;
    }

    function getError() {
        return "move along now, nothing to see here";
    }
}

class AccessManager {
    function login( $user, $pass ) {
        $ret = new User( $user );
        return $ret;
    }

    function getError() {
        return "move along now, nothing to see here";
    }
}

class CommandContext {
    private $params = array(); 
    private $error = "";

    function addParam( $key, $val ) { 
        $this->params[$key]=$val;
    }

    function get( $key ) { 
        return $this->params[$key];
    }

    function setError( $error ) {
        $this->error = $error;
    }
    function getError() {
        return $this->error;
    }
}

abstract class Command {
    abstract function execute();
}

class FeedbackCommand {
    private $msgSystem;
    function __construct( MessageSystem $msgSystem ) {
        $this->msgSystem = $msgSystem;
    }

    function execute( CommandContext $context ) {
        $email = $context->get( 'email' );
        $msg = $context->get( 'pass' );
        $topic = $context->get( 'topic' );
        $result = $this->msgSystem->despatch( $email, $msg, $topic );
        if ( ! $user ) {
            $this->context->setError( $this->msgSystem->getError() );
            return false;
        }
        $context->addParam( "user", $user );
        return true;
    }
}

class LoginCommand {
    private $manager;
    function __construct( AccessManager $mgr ) {
        $this->manager = $mgr;
    }

    function execute( CommandContext $context ) {
        $user = $context->get( 'username' );
        $pass = $context->get( 'pass' );
        $user = $this->manager->login( $user, $pass );
        if ( ! $user ) {
            $this->context->setError( $this->manager->getError() );
            return false;
        }
        $context->addParam( "user", $user );
        return true;
    }
}


$context = new CommandContext();
$context->addParam( "username", "bob" );
$context->addParam( "pass", "tiddles" );
$cmd = new LoginCommand( new AccessManager() );
if ( ! $cmd->execute( $context ) ) {
    print "an error occurred: ".$context->getError();
} else {
    print "successful login\n";
    $user_obj = $context->get( "user" );
}
