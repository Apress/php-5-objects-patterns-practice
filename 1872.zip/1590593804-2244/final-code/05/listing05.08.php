<?php
require_once( 'business/ShopProduct.php' );
require_once( 'util/UsefulClass.php' );

print_r( get_declared_classes() );
require_once( 'business/User.php' );
?>
