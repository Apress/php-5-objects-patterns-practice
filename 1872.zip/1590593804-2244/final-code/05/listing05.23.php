<?php
require_once( 'ShopProduct.php' );
require_once( 'getCD.php' );
var_dump( getProduct() );

// object(CdProduct)#1 (7) {
//   ["playLength:private"]=>
//   float(60.33)
//   ["coverUrl"]=>
//   string(0) ""
//   ["title:private"]=>
//   string(25) "Exile on Coldharbour Lane"
//   ["producerMainName:private"]=>
//   string(9) "Alabama 3"
//   ["producerFirstName:private"]=>
//   string(3) "The"
//   ["price:protected"]=>
//   float(10.99)
//   ["discount:private"]=>
//   int(0)
// }



?>
