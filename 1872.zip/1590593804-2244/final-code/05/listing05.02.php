<?php
require_once('business/User.php');
require_once('forum/User.php');
// Fatal error: Cannot redeclare class user in...
?>
