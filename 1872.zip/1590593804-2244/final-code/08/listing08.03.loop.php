<?php
require_once("DB.php");
$dsn_array[] = "mysql://bob:bobs_pass@localhost/bobs_db";
$dsn_array[] = "sqlite://./bobs_db.db";    

foreach ( $dsn_array as $dsn ) {
    print "$dsn\n\n";
    $db = DB::connect($dsn);
    $query_result = $db->query( "SELECT * FROM bobs_table" );
    while ( $row = $query_result->fetchRow( DB_FETCHMODE_ARRAY ) ) {
        printf( "| %-4s| %-4s| %-25s|", $row[0], $row[2], $row[1] );
        print "\n";
    }
    print "\n";
    $query_result->free();
    $db->disconnect();
}

?>
