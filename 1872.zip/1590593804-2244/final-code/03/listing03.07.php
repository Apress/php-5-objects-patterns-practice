<?php
require_once( "listing03.10.php" );

class ShopProductWriter {
    public function write( ShopProduct $shopProduct ) {
        $str  = "{$shopProduct->title}: ";   
        $str .= $shopProduct->getProducer();
        $str .= " ({$shopProduct->price})\n";
        print $str;
    }
}
class Wrong { }
$product1 = new ShopProduct( "My Antonia", "Willa", "Cather", 5.99 );
$writer = new ShopProductWriter();
$wrong  = new Wrong();
// $writer->write( $product1 );
$writer->write( $wrong );

?>
