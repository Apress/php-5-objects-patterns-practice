<?php
require_once( "listing04.03.php" );

abstract class ShopProductWriter {
    protected $products = array();

    public function addProduct( ShopProduct $shopProduct ) {
        $this->products[]=$shopProduct;
    }

    abstract public function write( );
    abstract static function pibble();
}

class ErroredWriter extends ShopProductWriter{
    protected function write() {}
    public static function pibble() {}
}

$writer = new ErroredWriter();
?>
