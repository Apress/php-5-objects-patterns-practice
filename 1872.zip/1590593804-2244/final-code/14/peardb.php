<?php
require_once("DB.php");

function connect() {

$dsn = "sqlite://./test.db";    
$db = DB::connect($dsn);

return $db;
}
$db = connect();

if ( PEAR::isError( $db ) ) {
    print "message:    ". $db->getMessage()   ."\n";
    print "code:       ". $db->getCode()      ."\n\n";
    print "Backtrace:\n";
    
    foreach ( $db->getBacktrace() as $caller ) {
        print $caller['class'].$caller['type'].$caller['function']."() ";
        print "line ".$caller['line']."\n";
        print_r( $caller );
    }
    die;
}

//drop and recreate table 'scores'
$db->query( "DROP TABLE scores" );
$db->query( "CREATE TABLE scores (  id INT PRIMARY KEY, 
                                    name varchar(255), 
                                    score INT )");

//add some rows
foreach ( array( 
            array( 'harry', 44), 
            array( 'mary', 66 ) ) as $row ) {
    $id = $db->nextId('score_sequence');
    $ret = $db->query( "insert into scores values( $id, '$row[0]', $row[1])" );
}

// output the rows
$query_result = $db->query( "SELECT * FROM scores");
while ( $row = $query_result->fetchRow( DB_FETCHMODE_ASSOC ) ) {
    print "row: {$row['id']} {$row['name']} {$row['score']}\n";
}

$query_result->free();
$db->disconnect();

?>
