<?php

class Login {
    const LOGIN_USER_UNKNOWN = 1;
    const LOGIN_WRONG_PASS   = 2;
    const LOGIN_ACCESS       = 3;

    function handleLogin( $user, $pass, $ip ) {
        switch ( rand(1,3) ) {
            case 1: 
                $this->setStatus( self::LOGIN_ACCESS );
                $this->cookiePartners( $user, $pass, $ip );
                $ret = true; break;
            case 2:
                $this->setStatus( self::LOGIN_WRONG_PASS );
                $ret = false; break;
            case 3:
                $this->setStatus( self::LOGIN_USER_UNKNOWN );
                $ret = false; break;
        }
        if ( ! $ret ) {
            Notifier::mailWarning( $user, $ip,$this->loginStatus()  );
        }
        Logger::logIP( $user, $ip, $this->loginStatus() );
        return $ret;
    }

    function cookiePartners( $user, $Ip ) {
        ;
    }

    private function setStatus( $status ) {
        $this->status = $status; 
    }

    function loginStatus() {
        return $this->status;
    }

}

class Notifier {
    function mailWarning( $user, $ip, $status ) {
        // mail sysadmin
    }
}

class Logger {
    function logIP( $user, $ip, $status ) {
        // log info
    }
}

$login = new Login();
$login->handleLogin( "bob","mypass", '158.152.55.35' );
print $login->loginStatus();
?>
