<?php
define('PHPUnit2_MAIN_METHOD', 'AppTests::main');

require_once( "PHPUnit2/Framework/TestSuite.php" );
require_once( "PHPUnit2/TextUI/TestRunner.php" );

require_once( "tests/UserTest.php" );
require_once( "tests/UserStoreTest.php" );
require_once( "tests/ValidatorTest.php" );
 

class AppTests { 
    public static function main() {
        $ts = new PHPUnit2_Framework_TestSuite( 'User Classes');
        $ts->addTestSuite('UserTest');
        $ts->addTestSuite('UserStoreTest');
        $ts->addTestSuite('ValidatorTest');
        PHPUnit2_TextUI_TestRunner::run( $ts );
    }
}

AppTests::main();
?>
