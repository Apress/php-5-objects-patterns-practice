<?php
require_once( 'ShopProduct.php' );

print_r( get_class_vars( 'CdProduct' ) );
print_r( get_class_vars( 'ShopProduct' ) );
print_r( get_class_vars( 'BookProduct' ) );

// Array
// (
//     [cdproductplayLength] => 0
//     [coverUrl] =>
//     [shopproducttitle] =>
//     [shopproductproducerMainName] =>
//     [shopproductproducerFirstName] =>
//     [*price] =>
//     [shopproductdiscount] => 0
// )

?>
