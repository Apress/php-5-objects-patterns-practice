<?php
require_once('User.php');
require_once('PHPUnit2/Framework/TestCase.php');
require_once('PHPUnit2/Framework/Test.php');


class UserTest extends PHPUnit2_Framework_TestCase {
    private $user;

    public function setUp() {
        $this->user = new User( "bob williams", 
                                "bob@example.com", 
                                "fantopedia" );
    }
    
    public function  testGetMail() {
        $mail = $this->user->getMail(); 
        $this->assertType(  "string", $mail );
        $this->assertEquals(  "bob@example.com", $mail );
    }
}

?>
