<?php

class PrintMe{ }
$test = new PrintMe();
print $test;
// output: Object id #1
