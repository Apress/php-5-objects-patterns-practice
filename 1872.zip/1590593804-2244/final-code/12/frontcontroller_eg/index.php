<?php
#require_once( "woo/mapper.php" );
#require_once( "woo/domain.php" );
require_once( "woo/controller/Controller.php" );
woo_controller_Controller::run();

?>
