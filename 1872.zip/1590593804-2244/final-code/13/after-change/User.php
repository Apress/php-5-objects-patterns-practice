<?php

class User {
    private $name;
    private $mail;
    private $pass;

    function __construct( $name, $mail, $pass ) {
        $this->name       = $name;
        $this->mail       = $mail;
        $this->pass       = $pass;
    }

    function getMail() {
        return $this->mail;
    }
}
?>
