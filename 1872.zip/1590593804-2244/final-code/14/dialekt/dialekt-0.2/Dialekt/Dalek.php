<?php
print "I am a Dalek\n";
?>
