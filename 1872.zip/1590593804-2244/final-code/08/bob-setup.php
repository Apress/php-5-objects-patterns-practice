<?php
require_once("DB.php");

$dsn[] = "mysql://bob:pass@localhost/test";
$dsn[] = "sqlite://./bobs_db.db";    
$table = "bobs_table";
$create =   "CREATE TABLE $table (  id INT PRIMARY KEY, 
                                    lesson_name varchar(255), 
                                    duration    int )";
$insert = array(    
            array( "lesson_name" => "applied doodads", 
                   "duration"    => 3 ),
            array( "lesson_name" => "how to spam", 
                   "duration"    => 2 ),
);

foreach ( $dsn as $str ) {
    $db = DB::connect($str);
    @$db->query( "DROP TABLE $table" );
    $db->query( $create );

    $delete_query = $db->query( "delete from $table" );
    if ( DB::isError( $delete_query ) ) {    
        die ($delete_query->getMessage());
    }

    foreach ( $insert as $row ) {                    
        $id = $db->nextId( $table.'_sequence');
        $row['id'] = $id;
        $db->autoExecute( $table, $row, DB_AUTOQUERY_INSERT );
        $db->disconnect();
    }
}
?>
