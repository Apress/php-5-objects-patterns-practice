<?php

set_include_path( get_include_path().":/home/john/phplib/"); 
print get_include_path();
?>
