<?php
require_once( "woo/base/Registry.php" );

class VH {
    static function getRequest() {
        return woo_base_RequestRegistry::getRequest();
    }
}

?>
