<?php
require_once( 'ShopProduct.php' );

print get_parent_class( 'CdProduct' );

// shopproduct

?>
