<?php

class AbstractClass {
    function abstractFunction() {
        die( "AbstractClass::abstractFunction() is abstract\n" );
    }
}

class ConcreteClass extends AbstractClass {}

$test = new ConcreteClass();
$test->abstractFunction();
