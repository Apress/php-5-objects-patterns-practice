<?php
require_once "lib/ML_Interpreter.php";
require_once "lib/Context.php";

$context = new Context();
$input = new VariableExpression( 'input' );
$statement = new BooleanOrExpression( 
    new EqualsExpression( $input, new LiteralExpression( 'four' ) ),
    new EqualsExpression( $input, new LiteralExpression( '4' ) ) 
);

foreach ( array( "four", "4", "52" ) as $val ) {
    $input->setValue( $val ); 
    print "$val:\n";
    $statement->interpret( $context );
    if ( $context->lookup( $statement ) ) {
        print "top marks\n\n";
    } else {
        print "dunce hat on\n\n";
    }
}

?>
