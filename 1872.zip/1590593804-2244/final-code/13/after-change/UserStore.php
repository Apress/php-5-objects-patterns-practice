<?php

class UserStore {
    private $users = array();
    function addUser( $name=null, $mail=null, $pass=null ) {
        if ( is_null( $name ) || is_null( $mail ) || is_null( $pass ) ) {
            return false;
        }

        $this->users[$mail] = new User( $name, $mail, $pass ); 

        if ( strlen( $pass ) < 5 ) {
            throw new Exception("Password must have 5 or more letters");
        }
        return true;
    }

    function getUser( $mail ) {
        return ( $this->users[$mail] ); 
    }
}

?>
